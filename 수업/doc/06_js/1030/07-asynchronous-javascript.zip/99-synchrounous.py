print('첫번째 작업')

for i in range(10):
    print('메인 작업')

print('마지막 작업')
