-- 01. Querying data


-- 02. Sorting data


-- NULL 정렬 예시


-- 03. Filtering data


-- 04. Grouping data


-- 에러


-- 에러 해결
